This project aims to build a calculator which can perform basic arithmetic in any base.
Future of the project is not decided as of yet. Tentatively it will become a new module for Python!
The inspiration for this project comes from "What is Mathematics?" book by Richard Courant. 
